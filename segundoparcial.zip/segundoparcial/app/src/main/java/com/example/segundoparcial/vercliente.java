package com.example.segundoparcial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class vercliente extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vercliente);
    }
}