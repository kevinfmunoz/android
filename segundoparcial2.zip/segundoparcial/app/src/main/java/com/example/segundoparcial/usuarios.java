package com.example.segundoparcial;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class usuarios extends AppCompatActivity {

    RecyclerView rvusuario;
    Adaptadorusuario adaptadorusuario;
    List<usuarios> usuarios = new ArrayList<>();
    Button btNuevo;
    Database miDB;

    String nombre;
    String apellido;
    int dni;
    int edad;
    String direccion;
    String email;

    public usuarios(String nombre, String apellido,int dni,int edad,String direccion,String email ) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.edad = edad;
        this.direccion = direccion;
        this.email = email;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes);

        miDB = new Database(this);

    }

    ActivityResultLauncher<Intent> nuevoLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            if(result.getResultCode() == RESULT_OK){
                cargarusuarios();

            }
        }
    });

    public void cargarusuarios(){
        usuarios = miDB.listausuarioQuery();
        adaptadorusuario = new Adaptadorusuario(this, usuarios);
        rvusuario.setAdapter(adaptadorusuario);
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getDnini() {
        return dni;
    }
    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String nombre) {
        this.direccion = direccion;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String nombre) {
        this.email = email;
    }
}