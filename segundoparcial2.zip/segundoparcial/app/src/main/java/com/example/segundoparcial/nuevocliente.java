package com.example.segundoparcial;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class nuevocliente extends AppCompatActivity {

    private EditText etNombre, etApellido, etDNI, etEdad, etDireccion, etEmail;

    private String urlAgregarCliente = "http://www.ragamese.com/curso_android/nuevo_cliente.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevocliente);

        Toolbar toolbar = findViewById(R.id.toolbarNuevoCliente);
        setSupportActionBar(toolbar);


        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        etNombre = findViewById(R.id.nombre);
        etApellido = findViewById(R.id.apellido);
        etDNI = findViewById(R.id.dni);
        etEdad = findViewById(R.id.edad);
        etDireccion = findViewById(R.id.direccion);
        etEmail = findViewById(R.id.email);

        Button btnAgregar = findViewById(R.id.btAceptar);
        btnAgregar.setOnClickListener(v -> agregarCliente());
    }

    private void agregarCliente() {

        String nombre = etNombre.getText().toString().trim();
        String apellido = etApellido.getText().toString().trim();
        String dni = etDNI.getText().toString().trim();
        String edad = etEdad.getText().toString().trim();
        String direccion = etDireccion.getText().toString().trim();
        String email = etEmail.getText().toString().trim();


        if (nombre.isEmpty() || apellido.isEmpty() || dni.isEmpty() || edad.isEmpty() || direccion.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        // Aquí se realizaría la llamada a la API para agregar el nuevo cliente usando Volley o Retrofit
        // Ejemplo con Volley:
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.POST, urlAgregarCliente,
                response -> {
                    // Procesar la respuesta de la API si es necesario

                    // Cerrar esta actividad y regresar a la pantalla de Clientes
                    finish();
                },
                error -> {
                    // Manejar errores en la solicitud a la API
                    Toast.makeText(this, "Error al agregar el cliente", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Parámetros para enviar a la API
                Map<String, String> params = new HashMap<>();
                params.put("nombre", nombre);
                params.put("apellido", apellido);
                params.put("dni", dni);
                params.put("edad", edad);
                params.put("direccion", direccion);
                params.put("email", email);
                params.put("usuario", "usuario_ejemplo"); // Ejemplo de usuario (puedes obtenerlo de algún lugar)

                return params;
            }
        };

        // Agregar la solicitud a la cola de solicitudes
        requestQueue.add(request);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Manejar la acción de clic en la flecha de retroceso en la barra de herramientas
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}