package com.example.segundoparcial;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Clientes extends AppCompatActivity {

    Button btclientes;

    RequestQueue peticiones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes);

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitNetwork().build());

        peticiones = Volley.newRequestQueue(this);

        btPagina = findViewById(R.id.btclientes);
        btPagina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String resul = "";
                try {
                    URL url = new URL("http://ragamese.com/curso_android/index.html");
                    HttpURLConnection conexion = (HttpURLConnection) url.openConnection();

                    if (conexion.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
                        String linea = reader.readLine();
                        while (linea != null) {
                            resul += linea;
                            linea = reader.readLine();
                        }
                        reader.close();
                    }
                    else {
                        resul = "ERROR: " + conexion.getResponseMessage();
                    }
                    conexion.disconnect();

                }
                catch (IOException e) {
                    resul = "ERROR2: " + e.getMessage();
                }

                Log.d("#####", "RESUL: " + resul);
            }
        });



    }

    private void obtenerDatosConVolleyUsuarios(){
        String url = "http://www.ragamese.com/curso_android/buscar_clientes.php";

        StringRequest peticion = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String respuesta) {
                        Log.d("#####", "RESUL CON VOLLEY: " + respuesta);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //ERROR
                        Log.d("#####", "ERROR: " + error.getMessage());
                    }
                }
        );

        peticiones.add(peticion);
    }
}


