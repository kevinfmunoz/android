package com.example.segundoparcial;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class Adaptadorusuario extends RecyclerView.Adapter<Adaptadorusuario.ViewHolder> {

    LayoutInflater inflador;
    List<usuarios> lista;
    private View.OnClickListener onClickListener;
    Context contexto;

    public Adaptadorusuario(Context context, List<usuarios> lista) {
        this.lista = lista;
        contexto = context;
        inflador = LayoutInflater.from(context);
    }

    public void setOnItemClickListener(View.OnClickListener onClickListener){
        this.onClickListener = onClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflador.inflate(R.layout.item_lista_usuarios, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        usuarios p = lista.get(position);
        holder.tvNombre.setText(p.getNombre());
        holder.tvedad.setText(p.getEdad());
        Glide.with(contexto)
                .load("https://cdn-icons-png.flaticon.com/512/6976/6976927.png")
                .error(R.drawable.error_image)
                .into(holder.ivImagen);
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvNombre;
        public TextView tvedad;
        public ImageView ivImagen;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvedad = itemView.findViewById(R.id.tvedad);
            ivImagen = itemView.findViewById(R.id.ivImagen);
        }
    }
}
